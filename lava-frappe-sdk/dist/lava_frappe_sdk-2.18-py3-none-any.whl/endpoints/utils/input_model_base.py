

class POSException(Exception):
    pass
