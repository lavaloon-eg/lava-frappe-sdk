
from .utils.insights import ApplicationInsights

insights = ApplicationInsights()
